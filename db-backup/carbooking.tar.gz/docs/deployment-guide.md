# host
ssh adminplk@61.19.112.242 -p 2233

# password
Plkhe@lth00051

## docker postgresql
container name = postgres_17_db
port = 5433
db = carbooking
user =admin

## web app
port = 3007