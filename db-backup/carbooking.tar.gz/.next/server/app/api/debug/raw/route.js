var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/debug/raw/route.js")
R.c("server/chunks/[root-of-the-server]__06056a85._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_debug_raw_route_actions_1031fa61.js")
R.m(6207)
module.exports=R.m(6207).exports
