var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/debug/db/route.js")
R.c("server/chunks/[root-of-the-server]__e133c54e._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_debug_db_route_actions_caf35022.js")
R.m(75782)
module.exports=R.m(75782).exports
