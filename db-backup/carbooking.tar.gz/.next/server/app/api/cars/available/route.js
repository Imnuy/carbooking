var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cars/available/route.js")
R.c("server/chunks/[root-of-the-server]__a884bcd9._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_cars_available_route_actions_47f8ed80.js")
R.m(53497)
module.exports=R.m(53497).exports
