var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/cars/route.js")
R.c("server/chunks/[root-of-the-server]__db8f3bb2._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_cars_route_actions_7042c64f.js")
R.m(75037)
module.exports=R.m(75037).exports
