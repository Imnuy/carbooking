var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/cars/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__f181c349._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_cars_[id]_route_actions_ea293200.js")
R.m(76181)
module.exports=R.m(76181).exports
