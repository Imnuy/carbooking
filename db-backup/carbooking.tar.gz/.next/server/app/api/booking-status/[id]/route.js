var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/booking-status/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__7d797153._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_booking-status_[id]_route_actions_2d400482.js")
R.m(77219)
module.exports=R.m(77219).exports
