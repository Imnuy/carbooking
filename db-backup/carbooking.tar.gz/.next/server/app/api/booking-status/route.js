var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/booking-status/route.js")
R.c("server/chunks/[root-of-the-server]__32a9504f._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_booking-status_route_actions_9e161e96.js")
R.m(11846)
module.exports=R.m(11846).exports
