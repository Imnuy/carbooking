var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/reseed/route.js")
R.c("server/chunks/[root-of-the-server]__8c692b81._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_reseed_route_actions_5cf76959.js")
R.m(65865)
module.exports=R.m(65865).exports
