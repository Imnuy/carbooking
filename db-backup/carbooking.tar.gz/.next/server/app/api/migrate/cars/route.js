var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/cars/route.js")
R.c("server/chunks/[root-of-the-server]__3deb7efc._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_cars_route_actions_a0417b55.js")
R.m(6525)
module.exports=R.m(6525).exports
