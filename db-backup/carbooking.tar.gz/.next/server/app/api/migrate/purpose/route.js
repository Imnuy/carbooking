var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/purpose/route.js")
R.c("server/chunks/[root-of-the-server]__9345c30b._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_purpose_route_actions_ce67a9f0.js")
R.m(35347)
module.exports=R.m(35347).exports
