var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/status/route.js")
R.c("server/chunks/[root-of-the-server]__5d9a7fc1._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_status_route_actions_da354ae4.js")
R.m(28786)
module.exports=R.m(28786).exports
