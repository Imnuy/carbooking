var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/collation/route.js")
R.c("server/chunks/[root-of-the-server]__4cf05478._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_collation_route_actions_c69fdb27.js")
R.m(97471)
module.exports=R.m(97471).exports
