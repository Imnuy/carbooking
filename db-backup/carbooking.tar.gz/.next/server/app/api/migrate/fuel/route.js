var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/migrate/fuel/route.js")
R.c("server/chunks/[root-of-the-server]__d71c5cfe._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_migrate_fuel_route_actions_9c7ec27c.js")
R.m(19784)
module.exports=R.m(19784).exports
