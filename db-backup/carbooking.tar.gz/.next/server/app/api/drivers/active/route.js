var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/active/route.js")
R.c("server/chunks/[root-of-the-server]__f075070f._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_active_route_actions_c3d1bc37.js")
R.m(22677)
module.exports=R.m(22677).exports
