var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__1a789c41._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_[id]_route_actions_b71c8a15.js")
R.m(28420)
module.exports=R.m(28420).exports
