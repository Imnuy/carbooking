var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/drivers/route.js")
R.c("server/chunks/[root-of-the-server]__426c6cfb._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_drivers_route_actions_9656ed85.js")
R.m(56948)
module.exports=R.m(56948).exports
