var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/pending/route.js")
R.c("server/chunks/[root-of-the-server]__3b4d54be._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_pending_route_actions_f14cdcf3.js")
R.m(66409)
module.exports=R.m(66409).exports
