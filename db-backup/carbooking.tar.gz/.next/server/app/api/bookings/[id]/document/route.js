var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/[id]/document/route.js")
R.c("server/chunks/[root-of-the-server]__ce6995be._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_e13e733f._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_[id]_document_route_actions_7803b4f2.js")
R.m(96290)
module.exports=R.m(96290).exports
