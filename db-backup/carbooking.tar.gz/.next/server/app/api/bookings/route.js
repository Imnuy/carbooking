var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/bookings/route.js")
R.c("server/chunks/[root-of-the-server]__50c4b317._.js")
R.c("server/chunks/[root-of-the-server]__6ac8ec31._.js")
R.c("server/chunks/_next-internal_server_app_api_bookings_route_actions_eb288a0b.js")
R.m(43191)
module.exports=R.m(43191).exports
