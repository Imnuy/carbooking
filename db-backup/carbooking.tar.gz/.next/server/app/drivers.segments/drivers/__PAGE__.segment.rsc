1:"$Sreact.fragment"
2:I[16566,["/_next/static/chunks/543b129255d5c517.js","/_next/static/chunks/f42b195a487b6abb.js","/_next/static/chunks/afdf071b48ccb072.js","/_next/static/chunks/bc04a7895db4b7c9.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"Pf60dwPtbFjeKaYpfjwG2","rsc":["$","$1","c",{"children":[["$","$L2",null,{"drivers":[{"id":1,"fullname":"คนขับรถ ทดสอบ 1","driver_type_code":"01","driver_type":"พนักงานขับรถเป็นครั้งคราว","is_active":true,"note":"พนักงานขับรถประจำ","created_at":"$D2026-03-16T09:07:20.261Z"},{"id":2,"fullname":"คนขับรถ ทดสอบ 2","driver_type_code":"01","driver_type":"พนักงานขับรถเป็นครั้งคราว","is_active":true,"note":"พนักงานขับรถชั่วคราว","created_at":"$D2026-03-16T09:07:20.261Z"}]}],[["$","script","script-0",{"src":"/_next/static/chunks/afdf071b48ccb072.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/bc04a7895db4b7c9.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
