1:"$Sreact.fragment"
2:I[62714,["/_next/static/chunks/543b129255d5c517.js","/_next/static/chunks/f42b195a487b6abb.js","/_next/static/chunks/9c47d228c01edca1.js","/_next/static/chunks/bc04a7895db4b7c9.js"],"default"]
3:I[97367,["/_next/static/chunks/ff1a16fafef87110.js","/_next/static/chunks/d2be314c3ece3fbe.js"],"OutletBoundary"]
4:"$Sreact.suspense"
0:{"buildId":"Pf60dwPtbFjeKaYpfjwG2","rsc":["$","$1","c",{"children":[["$","$L2",null,{"users":[{"id":2,"username":"user1","role":"user","fullname":"Staff 1","department":null,"created_at":"$D2026-03-16T08:38:35.784Z"},{"id":1,"username":"admin","role":"admin","fullname":"System Admin","department":null,"created_at":"$D2026-03-16T08:38:29.110Z"}]}],[["$","script","script-0",{"src":"/_next/static/chunks/9c47d228c01edca1.js","async":true}],["$","script","script-1",{"src":"/_next/static/chunks/bc04a7895db4b7c9.js","async":true}]],["$","$L3",null,{"children":["$","$4",null,{"name":"Next.MetadataOutlet","children":"$@5"}]}]]}],"loading":null,"isPartial":false}
5:null
