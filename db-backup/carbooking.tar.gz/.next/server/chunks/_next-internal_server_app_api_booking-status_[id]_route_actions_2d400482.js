module.exports=[91990,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_booking-status_%5Bid%5D_route_actions_2d400482.js.map