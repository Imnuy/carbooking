module.exports=[70742,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_cars_route_actions_a0417b55.js.map