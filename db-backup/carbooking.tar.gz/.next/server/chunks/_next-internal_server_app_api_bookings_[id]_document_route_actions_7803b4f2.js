module.exports=[12295,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bookings_%5Bid%5D_document_route_actions_7803b4f2.js.map