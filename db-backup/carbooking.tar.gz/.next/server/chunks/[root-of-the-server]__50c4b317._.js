module.exports=[62294,e=>e.a(async(t,r)=>{try{var a=e.i(23862),i=t([a]);[a]=i.then?(await i)():i;let s=new a.Pool({host:process.env.DB_HOST,port:parseInt(process.env.DB_PORT||"5432",10),user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,ssl:!1,max:10,idleTimeoutMillis:3e4,connectionTimeoutMillis:2e3});async function n(e,t){let r=Date.now();try{let a=await s.query(e,t),i=Date.now()-r;return console.log("Executed query",{text:e,duration:i,rows:a.rowCount}),a.rows}catch(t){throw console.error("Database query error:",{text:e,error:t}),t}}e.s(["queryWithEncoding",()=>n]),r()}catch(e){r(e)}},!1),23862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},62878,e=>{"use strict";function t(e){return"internal"===e||"external"===e}e.s(["BOOKING_STATUS",0,{pending:"001",assigned:"002",rejected:"003",completed:"004",cancelled:"005"},"isTripType",()=>t])},97469,e=>e.a(async(t,r)=>{try{var a=e.i(62294),i=e.i(62878),n=t([a]);[a]=n.then?(await n)():n;let l=null;async function s(){return l||(l=(await (0,a.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_name = 'bookings'
       AND column_name IN ('status_code', 'status')`)).some(e=>"status_code"===e.column_name)?"status_code":"status")}async function o(){let[e]=await (0,a.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.tables
       WHERE table_schema = 'public' AND table_name = 'trips'
     ) AS exists`);e?.exists||await (0,a.queryWithEncoding)(`CREATE TABLE trips (
        id SERIAL PRIMARY KEY,
        car_id INTEGER NULL REFERENCES cars(id) ON DELETE SET NULL,
        driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL,
        start_date_time TIMESTAMP NOT NULL,
        end_date_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(255),
        updated_by VARCHAR(255)
      )`);let t=(await (0,a.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'bookings'`)).map(e=>e.column_name);t.includes("trip_id")||await (0,a.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN trip_id INTEGER NULL");let[r]=await (0,a.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.table_constraints
       WHERE table_schema = 'public'
         AND table_name = 'bookings'
         AND constraint_type = 'FOREIGN KEY'
         AND constraint_name = 'bookings_trip_id_fkey'
     ) AS exists`);r?.exists||await (0,a.queryWithEncoding)("ALTER TABLE bookings ADD CONSTRAINT bookings_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE SET NULL"),t.includes("driver_id")||await (0,a.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL"),t.includes("driver_name")||await (0,a.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_name VARCHAR(255)");let n=await s();for(let e of(await (0,a.queryWithEncoding)(`UPDATE bookings b
     SET driver_id = d.id
     FROM drivers d
     WHERE b.driver_id IS NULL
       AND COALESCE(TRIM(b.driver_name), '') <> ''
       AND LOWER(TRIM(d.fullname)) = LOWER(TRIM(b.driver_name))`),await (0,a.queryWithEncoding)(`SELECT id, start_time, end_time, car_id, driver_id, created_at
     FROM bookings
     WHERE trip_id IS NULL
       AND car_id IS NOT NULL
       AND ${n} = $1
     ORDER BY created_at ASC, id ASC`,[i.BOOKING_STATUS.assigned]))){let t=await (0,a.queryWithEncoding)(`INSERT INTO trips (
         car_id,
         driver_id,
         start_date_time,
         end_date_time,
         created_at,
         updated_at,
         created_by,
         updated_by
       ) VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, $6, $7)
       RETURNING id`,[e.car_id,e.driver_id,e.start_time,e.end_time,e.created_at||new Date().toISOString(),"migration","migration"]),r=t[0]?.id;r&&await (0,a.queryWithEncoding)("UPDATE bookings SET trip_id = $1 WHERE id = $2 AND trip_id IS NULL",[r,e.id])}}function d(e){if(!e)return"";let t=e instanceof Date?e:new Date(e);return Number.isNaN(t.getTime())?"":t.toISOString().slice(0,10)}e.s(["ensureTripsSchema",()=>o,"resolveBookingStatusColumn",()=>s,"toDateKey",()=>d]),r()}catch(e){r(e)}},!1),30841,e=>e.a(async(t,r)=>{try{var a=e.i(89171),i=e.i(62294),n=e.i(62878),s=e.i(97469),o=t([i,s]);async function d(){try{await (0,s.ensureTripsSchema)();let e=await (0,s.resolveBookingStatusColumn)(),t=await (0,i.queryWithEncoding)(`SELECT
         b.*,
         b.${e} AS status_code,
         COALESCE(t.car_id, b.car_id) AS car_id,
         COALESCE(t.driver_id, b.driver_id) AS driver_id,
         COALESCE(d.fullname, b.driver_name) AS driver_name,
         c.brand,
         c.model,
         c.license_plate,
         u.fullname as owner_name,
         bs.status as status_text,
         t.start_date_time AS trip_start_date_time,
         t.end_date_time AS trip_end_date_time
       FROM bookings b
       LEFT JOIN trips t ON b.trip_id = t.id
       LEFT JOIN cars c ON COALESCE(t.car_id, b.car_id) = c.id
       LEFT JOIN drivers d ON COALESCE(t.driver_id, b.driver_id) = d.id
       JOIN users u ON b.user_id = u.id
       LEFT JOIN booking_status bs ON b.${e} = bs.code
       ORDER BY b.created_at DESC`);return a.NextResponse.json(t)}catch(e){return console.error("Error fetching bookings:",e),a.NextResponse.json({error:"Failed to fetch bookings"},{status:500})}}async function l(e){try{await (0,s.ensureTripsSchema)();let t=await (0,s.resolveBookingStatusColumn)(),{destination:r,purpose:o,fuel_reimbursement:d,distance:l,start_time:u,end_time:c,requester_name:E,requester_position:p,supervisor_name:_,supervisor_position:R,passengers:T,trip_type:m}=await e.json(),N=Number(T),h="string"==typeof m&&(0,n.isTripType)(m)?m:"internal";if(!E||!p||!_||!R)return a.NextResponse.json({error:"Requester and supervisor information is required"},{status:400});if(!r||!o||!u||!c)return a.NextResponse.json({error:"Trip details are required"},{status:400});if(!Number.isFinite(N)||N<1)return a.NextResponse.json({error:"Passenger count must be at least 1"},{status:400});let g=await (0,i.queryWithEncoding)(`INSERT INTO bookings (
        user_id,
        destination,
        purpose,
        fuel_reimbursement,
        distance,
        start_time,
        end_time,
        requester_name,
        requester_position,
        supervisor_name,
        supervisor_position,
        passengers,
        trip_type,
        ${t},
        created_at,
        created_by
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, CURRENT_TIMESTAMP, $15)
      RETURNING id`,[1,r,o,d||null,""!==l&&null!=l?Number(l):null,u,c,E,p,_,R,N,h,n.BOOKING_STATUS.pending,"requester"]);return a.NextResponse.json({success:!0,id:g[0].id})}catch(e){return console.error("Database error while creating booking:",e),a.NextResponse.json({error:"Internal Server Error"},{status:500})}}[i,s]=o.then?(await o)():o,e.s(["GET",()=>d,"POST",()=>l]),r()}catch(e){r(e)}},!1),43191,e=>e.a(async(t,r)=>{try{var a=e.i(47909),i=e.i(74017),n=e.i(96250),s=e.i(59756),o=e.i(61916),d=e.i(74677),l=e.i(69741),u=e.i(16795),c=e.i(87718),E=e.i(95169),p=e.i(47587),_=e.i(66012),R=e.i(70101),T=e.i(26937),m=e.i(10372),N=e.i(93695);e.i(52474);var h=e.i(220),g=e.i(30841),A=t([g]);[g]=A.then?(await A)():A;let v=new a.AppRouteRouteModule({definition:{kind:i.RouteKind.APP_ROUTE,page:"/api/bookings/route",pathname:"/api/bookings",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/bookings/route.ts",nextConfigOutput:"",userland:g}),{workAsyncStorage:y,workUnitAsyncStorage:x,serverHooks:w}=v;function S(){return(0,n.patchFetch)({workAsyncStorage:y,workUnitAsyncStorage:x})}async function b(e,t,r){v.isDev&&(0,s.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let a="/api/bookings/route";a=a.replace(/\/index$/,"")||"/";let n=await v.prepare(e,t,{srcPage:a,multiZoneDraftMode:!1});if(!n)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:g,params:A,nextConfig:S,parsedUrl:b,isDraftMode:y,prerenderManifest:x,routerServerContext:w,isOnDemandRevalidate:C,revalidateOnlyGenerated:L,resolvedPathname:O,clientReferenceManifest:f,serverActionsManifest:I}=n,D=(0,l.normalizeAppPath)(a),U=!!(x.dynamicRoutes[D]||x.routes[O]),k=async()=>((null==w?void 0:w.render404)?await w.render404(e,t,b,!1):t.end("This page could not be found"),null);if(U&&!y){let e=!!x.routes[O],t=x.dynamicRoutes[D];if(t&&!1===t.fallback&&!e){if(S.experimental.adapterPath)return await k();throw new N.NoFallbackError}}let q=null;!U||v.isDev||y||(q=O,q="/index"===q?"/":q);let M=!0===v.isDev||!U,P=U&&!M;I&&f&&(0,d.setManifestsSingleton)({page:a,clientReferenceManifest:f,serverActionsManifest:I});let $=e.method||"GET",F=(0,o.getTracer)(),H=F.getActiveScopeSpan(),W={params:A,prerenderManifest:x,renderOpts:{experimental:{authInterrupts:!!S.experimental.authInterrupts},cacheComponents:!!S.cacheComponents,supportsDynamicResponse:M,incrementalCache:(0,s.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:S.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,r,a,i)=>v.onRequestError(e,t,a,i,w)},sharedContext:{buildId:g}},j=new u.NodeNextRequest(e),B=new u.NodeNextResponse(t),G=c.NextRequestAdapter.fromNodeNextRequest(j,(0,c.signalFromNodeResponse)(t));try{let n=async e=>v.handle(G,W).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let r=F.getRootSpanAttributes();if(!r)return;if(r.get("next.span_type")!==E.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${r.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let i=r.get("next.route");if(i){let t=`${$} ${i}`;e.setAttributes({"next.route":i,"http.route":i,"next.span_name":t}),e.updateName(t)}else e.updateName(`${$} ${a}`)}),d=!!(0,s.getRequestMeta)(e,"minimalMode"),l=async s=>{var o,l;let u=async({previousCacheEntry:i})=>{try{if(!d&&C&&L&&!i)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let a=await n(s);e.fetchMetrics=W.renderOpts.fetchMetrics;let o=W.renderOpts.pendingWaitUntil;o&&r.waitUntil&&(r.waitUntil(o),o=void 0);let l=W.renderOpts.collectedTags;if(!U)return await (0,_.sendResponse)(j,B,a,W.renderOpts.pendingWaitUntil),null;{let e=await a.blob(),t=(0,R.toNodeOutgoingHttpHeaders)(a.headers);l&&(t[m.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let r=void 0!==W.renderOpts.collectedRevalidate&&!(W.renderOpts.collectedRevalidate>=m.INFINITE_CACHE)&&W.renderOpts.collectedRevalidate,i=void 0===W.renderOpts.collectedExpire||W.renderOpts.collectedExpire>=m.INFINITE_CACHE?void 0:W.renderOpts.collectedExpire;return{value:{kind:h.CachedRouteKind.APP_ROUTE,status:a.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:r,expire:i}}}}catch(t){throw(null==i?void 0:i.isStale)&&await v.onRequestError(e,t,{routerKind:"App Router",routePath:a,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:C})},!1,w),t}},c=await v.handleResponse({req:e,nextConfig:S,cacheKey:q,routeKind:i.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:x,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:L,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:d});if(!U)return null;if((null==c||null==(o=c.value)?void 0:o.kind)!==h.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==c||null==(l=c.value)?void 0:l.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});d||t.setHeader("x-nextjs-cache",C?"REVALIDATED":c.isMiss?"MISS":c.isStale?"STALE":"HIT"),y&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let E=(0,R.fromNodeOutgoingHttpHeaders)(c.value.headers);return d&&U||E.delete(m.NEXT_CACHE_TAGS_HEADER),!c.cacheControl||t.getHeader("Cache-Control")||E.get("Cache-Control")||E.set("Cache-Control",(0,T.getCacheControlHeader)(c.cacheControl)),await (0,_.sendResponse)(j,B,new Response(c.value.body,{headers:E,status:c.value.status||200})),null};H?await l(H):await F.withPropagatedContext(e.headers,()=>F.trace(E.BaseServerSpan.handleRequest,{spanName:`${$} ${a}`,kind:o.SpanKind.SERVER,attributes:{"http.method":$,"http.target":e.url}},l))}catch(t){if(t instanceof N.NoFallbackError||await v.onRequestError(e,t,{routerKind:"App Router",routePath:D,routeType:"route",revalidateReason:(0,p.getRevalidateReason)({isStaticGeneration:P,isOnDemandRevalidate:C})},!1,w),U)throw t;return await (0,_.sendResponse)(j,B,new Response(null,{status:500})),null}}e.s(["handler",()=>b,"patchFetch",()=>S,"routeModule",()=>v,"serverHooks",()=>w,"workAsyncStorage",()=>y,"workUnitAsyncStorage",()=>x]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__50c4b317._.js.map