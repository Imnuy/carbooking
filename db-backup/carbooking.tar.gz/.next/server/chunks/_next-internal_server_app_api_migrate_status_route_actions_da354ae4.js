module.exports=[42889,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_status_route_actions_da354ae4.js.map