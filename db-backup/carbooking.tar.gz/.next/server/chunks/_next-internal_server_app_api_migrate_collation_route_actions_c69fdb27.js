module.exports=[65482,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_collation_route_actions_c69fdb27.js.map