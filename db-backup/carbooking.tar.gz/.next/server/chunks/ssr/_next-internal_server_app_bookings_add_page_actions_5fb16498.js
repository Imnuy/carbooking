module.exports=[91162,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_bookings_add_page_actions_5fb16498.js.map