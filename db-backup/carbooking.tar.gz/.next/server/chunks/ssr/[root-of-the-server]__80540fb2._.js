module.exports=[93695,(a,b,c)=>{b.exports=a.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},23862,a=>a.a(async(b,c)=>{try{let b=await a.y("pg-587764f78a6c7a9c");a.n(b),c()}catch(a){c(a)}},!0),70864,a=>{a.n(a.i(33290))},43619,a=>{a.n(a.i(79962))},13718,a=>{a.n(a.i(85523))},18198,a=>{a.n(a.i(45518))},62212,a=>{a.n(a.i(66114))},66879,a=>a.a(async(b,c)=>{try{var d=a.i(23862),e=b([d]);[d]=e.then?(await e)():e;let g=new d.Pool({host:process.env.DB_HOST,port:parseInt(process.env.DB_PORT||"5432",10),user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,ssl:!1,max:10,idleTimeoutMillis:3e4,connectionTimeoutMillis:2e3});async function f(a,b){let c=Date.now();try{let d=await g.query(a,b),e=Date.now()-c;return console.log("Executed query",{text:a,duration:e,rows:d.rowCount}),d.rows}catch(b){throw console.error("Database query error:",{text:a,error:b}),b}}a.s(["queryWithEncoding",()=>f]),c()}catch(a){c(a)}},!1),57329,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/BookingListClient.tsx <module evaluation> from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/BookingListClient.tsx <module evaluation>","default")},8916,a=>{"use strict";a.s(["default",()=>b]);let b=(0,a.i(11857).registerClientReference)(function(){throw Error("Attempted to call the default export of [project]/components/BookingListClient.tsx from the server, but it's on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"[project]/components/BookingListClient.tsx","default")},17742,a=>{"use strict";a.i(57329);var b=a.i(8916);a.n(b)},32943,a=>{"use strict";a.s(["BOOKING_STATUS",0,{pending:"001",assigned:"002",rejected:"003",completed:"004",cancelled:"005"}])},88217,a=>a.a(async(b,c)=>{try{var d=a.i(66879),e=a.i(32943),f=b([d]);[d]=f.then?(await f)():f;let i=null;async function g(){return i||(i=(await (0,d.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_name = 'bookings'
       AND column_name IN ('status_code', 'status')`)).some(a=>"status_code"===a.column_name)?"status_code":"status")}async function h(){let[a]=await (0,d.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.tables
       WHERE table_schema = 'public' AND table_name = 'trips'
     ) AS exists`);a?.exists||await (0,d.queryWithEncoding)(`CREATE TABLE trips (
        id SERIAL PRIMARY KEY,
        car_id INTEGER NULL REFERENCES cars(id) ON DELETE SET NULL,
        driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL,
        start_date_time TIMESTAMP NOT NULL,
        end_date_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(255),
        updated_by VARCHAR(255)
      )`);let b=(await (0,d.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'bookings'`)).map(a=>a.column_name);b.includes("trip_id")||await (0,d.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN trip_id INTEGER NULL");let[c]=await (0,d.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.table_constraints
       WHERE table_schema = 'public'
         AND table_name = 'bookings'
         AND constraint_type = 'FOREIGN KEY'
         AND constraint_name = 'bookings_trip_id_fkey'
     ) AS exists`);c?.exists||await (0,d.queryWithEncoding)("ALTER TABLE bookings ADD CONSTRAINT bookings_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE SET NULL"),b.includes("driver_id")||await (0,d.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL"),b.includes("driver_name")||await (0,d.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_name VARCHAR(255)");let f=await g();for(let a of(await (0,d.queryWithEncoding)(`UPDATE bookings b
     SET driver_id = d.id
     FROM drivers d
     WHERE b.driver_id IS NULL
       AND COALESCE(TRIM(b.driver_name), '') <> ''
       AND LOWER(TRIM(d.fullname)) = LOWER(TRIM(b.driver_name))`),await (0,d.queryWithEncoding)(`SELECT id, start_time, end_time, car_id, driver_id, created_at
     FROM bookings
     WHERE trip_id IS NULL
       AND car_id IS NOT NULL
       AND ${f} = $1
     ORDER BY created_at ASC, id ASC`,[e.BOOKING_STATUS.assigned]))){let b=await (0,d.queryWithEncoding)(`INSERT INTO trips (
         car_id,
         driver_id,
         start_date_time,
         end_date_time,
         created_at,
         updated_at,
         created_by,
         updated_by
       ) VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, $6, $7)
       RETURNING id`,[a.car_id,a.driver_id,a.start_time,a.end_time,a.created_at||new Date().toISOString(),"migration","migration"]),c=b[0]?.id;c&&await (0,d.queryWithEncoding)("UPDATE bookings SET trip_id = $1 WHERE id = $2 AND trip_id IS NULL",[c,a.id])}}a.s(["ensureTripsSchema",()=>h,"resolveBookingStatusColumn",()=>g]),c()}catch(a){c(a)}},!1),87371,a=>a.a(async(b,c)=>{try{var d=a.i(7997),e=a.i(66879),f=a.i(17742),g=a.i(88217),h=b([e,g]);async function i({searchParams:a}){let b=await a,c="string"==typeof b.sort?b.sort:"created_at",h="string"==typeof b.order?b.order.toLowerCase():"desc",i=["id","start_time","created_at"].includes(c)?`b.${c}`:"b.created_at";await (0,g.ensureTripsSchema)();let j=await (0,g.resolveBookingStatusColumn)(),k=await (0,e.queryWithEncoding)(`SELECT
       b.*,
       b.${j} AS status_code,
       COALESCE(t.car_id, b.car_id) AS car_id,
       COALESCE(t.driver_id, b.driver_id) AS driver_id,
       COALESCE(d.fullname, b.driver_name) AS driver_name,
       c.brand,
       c.model,
       c.license_plate,
       u.fullname as owner_name,
       bs.status as status_text,
       t.start_date_time AS trip_start_date_time,
       t.end_date_time AS trip_end_date_time
     FROM bookings b 
     LEFT JOIN trips t ON b.trip_id = t.id
     LEFT JOIN cars c ON COALESCE(t.car_id, b.car_id) = c.id 
     LEFT JOIN drivers d ON COALESCE(t.driver_id, b.driver_id) = d.id
     JOIN users u ON b.user_id = u.id 
     LEFT JOIN booking_status bs ON b.${j} = bs.code
     ORDER BY ${i} ${"asc"===h?"ASC":"DESC"}`);return(0,d.jsx)(f.default,{initialBookings:k,sort:c,order:h})}[e,g]=h.then?(await h)():h,a.s(["default",()=>i]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__80540fb2._.js.map