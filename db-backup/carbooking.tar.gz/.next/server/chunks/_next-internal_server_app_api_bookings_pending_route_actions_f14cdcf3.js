module.exports=[61718,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_bookings_pending_route_actions_f14cdcf3.js.map