module.exports=[47080,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_fuel_route_actions_9c7ec27c.js.map