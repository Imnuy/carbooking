module.exports=[76162,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_migrate_purpose_route_actions_ce67a9f0.js.map