module.exports=[66073,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_drivers_active_route_actions_c3d1bc37.js.map