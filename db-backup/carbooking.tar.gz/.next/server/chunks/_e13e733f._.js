module.exports=[41915,e=>e.a(async(t,n)=>{try{var r=e.i(62294),a=e.i(62878),i=e.i(97469),o=t([r,i]);function s(e){return null==e?"":String(e).trim().replace(/[\u0E50-\u0E59]/g,e=>String(e.charCodeAt(0)-3664))}function l(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function d(e){if(!e)return{day:"",month:"",year:""};let t=new Date(e),n=new Intl.DateTimeFormat("th-TH-u-nu-latn",{day:"numeric",month:"long",year:"numeric"}).formatToParts(t);return{day:n.find(e=>"day"===e.type)?.value||"",month:n.find(e=>"month"===e.type)?.value||"",year:n.find(e=>"year"===e.type)?.value||""}}function c(e){let t=d(e);return[t.day,t.month,t.year].filter(Boolean).join(" ")}function m(e){return new Intl.DateTimeFormat("th-TH-u-nu-latn",{hour:"2-digit",minute:"2-digit",hour12:!1}).format(new Date(e))}function p(e,t,n=""){let r,a=["field",n].filter(Boolean).join(" ");return`<span class="${a}" style="min-width:${t}">${(r=s(e))?l(r):"&nbsp;"}</span>`}function u(e,t="105mm"){return`
    <div class="line-label">
      <span class="line-fill" style="width:${t}"></span>
      <span>${l(e)}</span>
    </div>
  `}function h(e){let t=s(e);return`(${l(t||" ")})`}function g(e,t){return`<div class="choice-row"><span class="choice-mark">${t?"☑":"☐"}</span><span>${l(e)}</span></div>`}function f(e){return`
    <header class="doc-header">
      <div class="doc-title">ใบขออนุญาตใช้รถยนต์ส่วนกลาง</div>
      <div class="doc-subtitle">(${"external"===e?"ต่างจังหวัด":"ในจังหวัด"})</div>
      <div class="doc-office">สำนักงานสาธารณสุขจังหวัดพิษณุโลก</div>
    </header>
  `}function b(e,t){return`<!DOCTYPE html>
<html lang="th">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>${l(e)}</title>
    <style>
    :root {
      color-scheme: light;
    }

    * {
      box-sizing: border-box;
    }

    html, body {
      margin: 0;
      padding: 0;
    }

    body {
      background: #edf2f7;
      color: #111827;
      font-family: "TH Sarabun New", "Sarabun", "Noto Sans Thai", Tahoma, sans-serif;
    }

    .toolbar {
      position: sticky;
      top: 0;
      z-index: 10;
      display: flex;
      justify-content: flex-end;
      gap: 12px;
      padding: 12px 16px;
      background: rgba(237, 242, 247, 0.92);
      backdrop-filter: blur(8px);
    }

    .toolbar button {
      border: 1px solid #cbd5e1;
      background: #ffffff;
      color: #0f172a;
      border-radius: 999px;
      padding: 8px 16px;
      font: inherit;
      cursor: pointer;
    }

    .sheet {
      width: 210mm;
      min-height: 297mm;
      margin: 12px auto 24px;
      background: #ffffff;
      box-shadow: 0 18px 40px rgba(15, 23, 42, 0.12);
      padding: 12mm 14mm 14mm;
    }

    .document {
      font-size: 18pt;
      line-height: 1.38;
    }

    .doc-header {
      text-align: center;
      margin-bottom: 10mm;
    }

    .doc-title {
      font-size: 22pt;
      font-weight: 700;
      line-height: 1.25;
    }

    .doc-subtitle {
      font-size: 20pt;
      font-weight: 700;
      line-height: 1.25;
      margin-top: 2mm;
    }

    .doc-office {
      font-size: 20pt;
      line-height: 1.25;
      margin-top: 2.5mm;
    }

    .form-block {
      margin-top: 2mm;
    }

    .text-row {
      margin: 0 0 2.6mm;
      line-height: 1.44;
    }

    .indent {
      padding-left: 9mm;
    }

    .right-align {
      text-align: right;
      margin-bottom: 4mm;
    }

    .field {
      display: inline-block;
      vertical-align: baseline;
      min-height: 7mm;
      padding: 0 1.2mm;
      border-bottom: none;
      white-space: pre-wrap;
      word-break: break-word;
    }

    .note-row {
      margin-top: 2mm;
    }

    .internal-signatures {
      display: flex;
      justify-content: flex-end;
      margin-top: 5mm;
    }

    .signature-panel {
      width: 84mm;
    }

    .signature-spacer {
      height: 12mm;
    }

    .signature-spacer.small {
      height: 8mm;
    }

    .line-label {
      display: flex;
      align-items: center;
      gap: 2mm;
    }

    .line-fill {
      display: inline-block;
      height: 0;
      border-bottom: 0.5pt solid #111827;
      transform: translateY(1.5mm);
    }

    .signature-name {
      text-align: center;
      margin-top: 1mm;
      min-height: 8mm;
    }

    .submitted-box {
      width: fit-content;
      min-width: 56mm;
      margin: 22mm auto 0;
      border: 1pt solid #111827;
      padding: 4mm 8mm;
      text-align: center;
      font-size: 18pt;
      font-weight: 700;
    }

    .vehicle-choices {
      margin: 5mm 0 6mm;
    }

    .choice-row {
      display: flex;
      align-items: center;
      gap: 3mm;
      margin-bottom: 2mm;
    }

    .choice-mark {
      display: inline-flex;
      width: 7mm;
      justify-content: center;
    }

    .external-grid {
      display: grid;
      grid-template-columns: 1.1fr 0.9fr;
      gap: 8mm;
      margin-top: 4mm;
      align-items: start;
    }

    @page {
      size: A4;
      margin: 12mm;
    }

    @media print {
      body {
        background: #ffffff;
      }

      .no-print {
        display: none !important;
      }

      .sheet {
        width: auto;
        min-height: auto;
        margin: 0;
        padding: 0;
        box-shadow: none;
      }
    }
  </style>
  </head>
  <body>
    <div class="toolbar no-print">
      <button type="button" onclick="window.print()">พิมพ์เอกสาร</button>
      <button type="button" onclick="window.close()">ปิดหน้าต่าง</button>
    </div>
    <main class="sheet">
      ${t}
    </main>
  </body>
</html>`}async function w(e){await (0,i.ensureTripsSchema)();let t=await (0,i.resolveBookingStatusColumn)(),n=(await (0,r.queryWithEncoding)(`SELECT
        b.id,
        b.requester_name,
        b.requester_position,
        b.supervisor_name,
        b.supervisor_position,
        b.destination,
        b.purpose,
        b.fuel_reimbursement,
        b.distance,
        b.passengers,
        b.trip_type,
        b.start_time,
        b.end_time,
        COALESCE(d.fullname, b.driver_name) AS driver_name,
        b.${t} AS status_code,
        b.created_at,
        c.brand,
        c.model,
        c.license_plate,
        c.car_type
     FROM bookings b
     LEFT JOIN trips t ON b.trip_id = t.id
     LEFT JOIN cars c ON COALESCE(t.car_id, b.car_id) = c.id
     LEFT JOIN drivers d ON COALESCE(t.driver_id, b.driver_id) = d.id
     WHERE b.id = $1
     LIMIT 1`,[e]))[0];return n?{...n,trip_type:(0,a.isTripType)(n.trip_type)?n.trip_type:"internal"}:null}function v(e){let t,n,r,a,i,o,w,v,x=`${s(e.requester_name)||`booking-${e.id}`} - ${"external"===e.trip_type?"ต่างจังหวัด":"ในจังหวัด"}`,y="external"===e.trip_type?(t=d(e.start_time),n=d(e.end_time),a=(r=`${s(e.car_type)} ${s(e.model)}`.toLowerCase().replace(/\s+/g,"")).includes("รถตู้")||r.includes("ตู้")||r.includes("van")||r.includes("commuter")?"van":r.includes("รถยนต์บรรทุก")||r.includes("truck")||r.includes("pickup")||r.includes("d-max")?r.includes("4ประตู")?"passenger":"truck":"passenger",i=[s(e.brand),s(e.model)].filter(Boolean).join(" "),`
    <section class="document external-document">
      ${f(e.trip_type)}

      <p class="text-row right-align">วันที่ ${l(c(e.created_at||e.start_time))}</p>

      <div class="form-block">
        <p class="text-row">เรียน นายแพทย์สาธารณสุขจังหวัดพิษณุโลก</p>

        <p class="text-row indent">
          ข้าพเจ้า ${p(e.requester_name,"54mm")}
          ตำแหน่ง ${p(e.requester_position,"84mm")}
        </p>

        <p class="text-row">
          ขออนุญาตนำรถยนต์ไปราชการที่ ${p(e.destination,"129mm")}
        </p>

        <p class="text-row">
          เพื่อ ${p(e.purpose,"85mm")}
          มีคนนั่ง ${p(e.passengers,"14mm")} คน
        </p>

        <p class="text-row">
          ในวันที่ ${p(t.day,"12mm")}
          เดือน ${p(t.month,"26mm")}
          พ.ศ. ${p(t.year,"18mm")}
          เวลา ${p(m(e.start_time),"22mm")} น.
        </p>

        <p class="text-row">
          ถึงวันที่ ${p(n.day,"12mm")}
          เดือน ${p(n.month,"26mm")}
          พ.ศ. ${p(n.year,"18mm")}
          เวลา ${p(m(e.end_time),"22mm")} น.
        </p>

        <p class="text-row">
          โดยมี ${p(e.supervisor_name,"110mm")}
          เป็นผู้ควบคุมรถ
        </p>

        <p class="text-row">
          หมายเหตุ เบิกงบประมาณค่าน้ำมันเชื้อเพลิงจากงาน/โครงการ
          ${p(e.fuel_reimbursement,"75mm")}
        </p>
      </div>

      <div class="vehicle-choices">
        ${g("รถตู้บรรทุก","van"===a)}
        ${g("รถยนต์บรรทุก","truck"===a)}
        ${g("รถยนต์นั่งบรรทุก 4 ประตู","passenger"===a)}
      </div>

      <div class="external-grid">
        <div class="external-left">
          <p class="text-row">เรียน นายแพทย์สาธารณสุขจังหวัดพิษณุโลก</p>
          <p class="text-row">1. การไปราชการครั้งนี้</p>
          <p class="text-row">
            ( ) เห็นสมควรอนุญาตให้นำรถยนต์ยี่ห้อ ${p(i,"60mm")}
          </p>
          <p class="text-row">
            หมายเลขทะเบียน ${p(e.license_plate,"34mm")}
            ส่งชื่อ ${p(e.driver_name,"60mm")}
          </p>
          <p class="text-row">ทำหน้าที่ พนักงานขับรถยนต์</p>
          <p class="text-row">( )</p>
          <p class="text-row">จึงเรียนมาเพื่อโปรดพิจารณาสั่งการต่อไป</p>
          <p class="text-row">ขอเป็นพระคุณ</p>
        </div>

        <div class="external-right">
          ${u("ผู้ขออนุญาตใช้รถยนต์","88mm")}
          <div class="signature-name">${h(e.requester_name)}</div>

          <div class="signature-spacer small"></div>

          ${u("หัวหน้ากลุ่มงาน/งาน","88mm")}

          <div class="signature-spacer"></div>

          ${u("ผู้มีอำนาจสั่งใช้รถยนต์","88mm")}
        </div>
      </div>
    </section>
  `):(o=d(e.start_time),w=d(e.end_time),v=c(e.created_at||e.start_time),`
    <section class="document internal-document">
      ${f(e.trip_type)}

      <div class="form-block">
        <p class="text-row">เรียน นายแพทย์สาธารณสุขจังหวัดพิษณุโลก</p>

        <p class="text-row indent">
          ข้าพเจ้า ${p(e.requester_name,"54mm")}
          ตำแหน่ง ${p(e.requester_position,"84mm")}
        </p>

        <p class="text-row">
          ขออนุญาตใช้รถยนต์ไปราชการที่ ${p(e.destination,"132mm")}
        </p>

        <p class="text-row">เพื่อ ${p(e.purpose,"162mm")}</p>

        <p class="text-row">
          มีคนนั่ง ${p(e.passengers,"16mm")} คน
          &nbsp;&nbsp;&nbsp;&nbsp;ในวันที่ ${p(o.day,"12mm")}
          เดือน ${p(o.month,"26mm")}
          พ.ศ. ${p(o.year,"18mm")}
          เวลา ${p(m(e.start_time),"22mm")} น.
        </p>

        <p class="text-row">
          ถึงวันที่ ${p(w.day,"12mm")}
          เดือน ${p(w.month,"26mm")}
          พ.ศ. ${p(w.year,"18mm")}
          เวลา ${p(m(e.end_time),"22mm")} น.
        </p>

        <p class="text-row">
          โดยมี ${p(e.supervisor_name,"120mm")}
          เป็นผู้ควบคุมรถ
        </p>

        <p class="text-row note-row">** หมายเหตุ กำหนดการตามเอกสารแนบ</p>
      </div>

      <div class="internal-signatures">
        <div class="signature-panel">
          ${u("ผู้ขออนุญาต")}
          <div class="signature-name">${h(e.requester_name)}</div>

          <div class="signature-spacer"></div>

          ${u("หัวหน้ากลุ่มงาน/งาน")}
        </div>
      </div>

      <div class="submitted-box">วันที่ส่งใบขอ ${l(v)}</div>
    </section>
  `);return b(x,y)}function x(e,t){return b(e,`<section class="document"><p class="text-row">${l(t)}</p></section>`)}[r,i]=o.then?(await o)():o,e.s(["getBookingPrintData",()=>w,"renderBookingPrintError",()=>x,"renderBookingPrintHtml",()=>v]),n()}catch(e){n(e)}},!1),11564,e=>e.a(async(t,n)=>{try{var r=e.i(89171),a=e.i(62878),i=e.i(41915),o=t([i]);async function s(e,{params:t}){try{let{id:e}=await t,n=await (0,i.getBookingPrintData)(e);if(!n)return new r.NextResponse((0,i.renderBookingPrintError)("Booking not found","ไม่พบข้อมูลใบขอใช้รถ"),{status:404,headers:{"Content-Type":"text/html; charset=utf-8"}});if(n.status_code!==a.BOOKING_STATUS.assigned)return new r.NextResponse((0,i.renderBookingPrintError)("Booking not ready","เอกสารสามารถพิมพ์ได้หลังจากจัดรถและพนักงานขับรถแล้วเท่านั้น"),{status:400,headers:{"Content-Type":"text/html; charset=utf-8"}});return new r.NextResponse((0,i.renderBookingPrintHtml)(n),{headers:{"Content-Type":"text/html; charset=utf-8"}})}catch(e){return console.error("Error rendering booking document:",e),new r.NextResponse((0,i.renderBookingPrintError)("Render failed","ไม่สามารถสร้างเอกสารสำหรับพิมพ์ได้"),{status:500,headers:{"Content-Type":"text/html; charset=utf-8"}})}}[i]=o.then?(await o)():o,e.s(["GET",()=>s]),n()}catch(e){n(e)}},!1),96290,e=>e.a(async(t,n)=>{try{var r=e.i(47909),a=e.i(74017),i=e.i(96250),o=e.i(59756),s=e.i(61916),l=e.i(74677),d=e.i(69741),c=e.i(16795),m=e.i(87718),p=e.i(95169),u=e.i(47587),h=e.i(66012),g=e.i(70101),f=e.i(26937),b=e.i(10372),w=e.i(93695);e.i(52474);var v=e.i(220),x=e.i(11564),y=t([x]);[x]=y.then?(await y)():y;let E=new r.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/bookings/[id]/document/route",pathname:"/api/bookings/[id]/document",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/app/api/bookings/[id]/document/route.ts",nextConfigOutput:"",userland:x}),{workAsyncStorage:R,workUnitAsyncStorage:k,serverHooks:C}=E;function $(){return(0,i.patchFetch)({workAsyncStorage:R,workUnitAsyncStorage:k})}async function _(e,t,n){E.isDev&&(0,o.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let r="/api/bookings/[id]/document/route";r=r.replace(/\/index$/,"")||"/";let i=await E.prepare(e,t,{srcPage:r,multiZoneDraftMode:!1});if(!i)return t.statusCode=400,t.end("Bad Request"),null==n.waitUntil||n.waitUntil.call(n,Promise.resolve()),null;let{buildId:x,params:y,nextConfig:$,parsedUrl:_,isDraftMode:R,prerenderManifest:k,routerServerContext:C,isOnDemandRevalidate:T,revalidateOnlyGenerated:A,resolvedPathname:N,clientReferenceManifest:O,serverActionsManifest:S}=i,P=(0,d.normalizeAppPath)(r),q=!!(k.dynamicRoutes[P]||k.routes[N]),H=async()=>((null==C?void 0:C.render404)?await C.render404(e,t,_,!1):t.end("This page could not be found"),null);if(q&&!R){let e=!!k.routes[N],t=k.dynamicRoutes[P];if(t&&!1===t.fallback&&!e){if($.experimental.adapterPath)return await H();throw new w.NoFallbackError}}let I=null;!q||E.isDev||R||(I=N,I="/index"===I?"/":I);let B=!0===E.isDev||!q,D=q&&!B;S&&O&&(0,l.setManifestsSingleton)({page:r,clientReferenceManifest:O,serverActionsManifest:S});let U=e.method||"GET",F=(0,s.getTracer)(),L=F.getActiveScopeSpan(),M={params:y,prerenderManifest:k,renderOpts:{experimental:{authInterrupts:!!$.experimental.authInterrupts},cacheComponents:!!$.cacheComponents,supportsDynamicResponse:B,incrementalCache:(0,o.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:$.cacheLife,waitUntil:n.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,n,r,a)=>E.onRequestError(e,t,r,a,C)},sharedContext:{buildId:x}},j=new c.NodeNextRequest(e),z=new c.NodeNextResponse(t),K=m.NextRequestAdapter.fromNodeNextRequest(j,(0,m.signalFromNodeResponse)(t));try{let i=async e=>E.handle(K,M).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let n=F.getRootSpanAttributes();if(!n)return;if(n.get("next.span_type")!==p.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${n.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let a=n.get("next.route");if(a){let t=`${U} ${a}`;e.setAttributes({"next.route":a,"http.route":a,"next.span_name":t}),e.updateName(t)}else e.updateName(`${U} ${r}`)}),l=!!(0,o.getRequestMeta)(e,"minimalMode"),d=async o=>{var s,d;let c=async({previousCacheEntry:a})=>{try{if(!l&&T&&A&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let r=await i(o);e.fetchMetrics=M.renderOpts.fetchMetrics;let s=M.renderOpts.pendingWaitUntil;s&&n.waitUntil&&(n.waitUntil(s),s=void 0);let d=M.renderOpts.collectedTags;if(!q)return await (0,h.sendResponse)(j,z,r,M.renderOpts.pendingWaitUntil),null;{let e=await r.blob(),t=(0,g.toNodeOutgoingHttpHeaders)(r.headers);d&&(t[b.NEXT_CACHE_TAGS_HEADER]=d),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let n=void 0!==M.renderOpts.collectedRevalidate&&!(M.renderOpts.collectedRevalidate>=b.INFINITE_CACHE)&&M.renderOpts.collectedRevalidate,a=void 0===M.renderOpts.collectedExpire||M.renderOpts.collectedExpire>=b.INFINITE_CACHE?void 0:M.renderOpts.collectedExpire;return{value:{kind:v.CachedRouteKind.APP_ROUTE,status:r.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:n,expire:a}}}}catch(t){throw(null==a?void 0:a.isStale)&&await E.onRequestError(e,t,{routerKind:"App Router",routePath:r,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:T})},!1,C),t}},m=await E.handleResponse({req:e,nextConfig:$,cacheKey:I,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:k,isRoutePPREnabled:!1,isOnDemandRevalidate:T,revalidateOnlyGenerated:A,responseGenerator:c,waitUntil:n.waitUntil,isMinimalMode:l});if(!q)return null;if((null==m||null==(s=m.value)?void 0:s.kind)!==v.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==m||null==(d=m.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});l||t.setHeader("x-nextjs-cache",T?"REVALIDATED":m.isMiss?"MISS":m.isStale?"STALE":"HIT"),R&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let p=(0,g.fromNodeOutgoingHttpHeaders)(m.value.headers);return l&&q||p.delete(b.NEXT_CACHE_TAGS_HEADER),!m.cacheControl||t.getHeader("Cache-Control")||p.get("Cache-Control")||p.set("Cache-Control",(0,f.getCacheControlHeader)(m.cacheControl)),await (0,h.sendResponse)(j,z,new Response(m.value.body,{headers:p,status:m.value.status||200})),null};L?await d(L):await F.withPropagatedContext(e.headers,()=>F.trace(p.BaseServerSpan.handleRequest,{spanName:`${U} ${r}`,kind:s.SpanKind.SERVER,attributes:{"http.method":U,"http.target":e.url}},d))}catch(t){if(t instanceof w.NoFallbackError||await E.onRequestError(e,t,{routerKind:"App Router",routePath:P,routeType:"route",revalidateReason:(0,u.getRevalidateReason)({isStaticGeneration:D,isOnDemandRevalidate:T})},!1,C),q)throw t;return await (0,h.sendResponse)(j,z,new Response(null,{status:500})),null}}e.s(["handler",()=>_,"patchFetch",()=>$,"routeModule",()=>E,"serverHooks",()=>C,"workAsyncStorage",()=>R,"workUnitAsyncStorage",()=>k]),n()}catch(e){n(e)}},!1)];

//# sourceMappingURL=_e13e733f._.js.map