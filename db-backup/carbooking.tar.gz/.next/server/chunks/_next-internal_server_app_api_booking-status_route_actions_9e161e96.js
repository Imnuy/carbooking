module.exports=[27468,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_booking-status_route_actions_9e161e96.js.map