module.exports=[62294,e=>e.a(async(t,r)=>{try{var i=e.i(23862),a=t([i]);[i]=a.then?(await a)():a;let s=new i.Pool({host:process.env.DB_HOST,port:parseInt(process.env.DB_PORT||"5432",10),user:process.env.DB_USER,password:process.env.DB_PASSWORD,database:process.env.DB_NAME,ssl:!1,max:10,idleTimeoutMillis:3e4,connectionTimeoutMillis:2e3});async function n(e,t){let r=Date.now();try{let i=await s.query(e,t),a=Date.now()-r;return console.log("Executed query",{text:e,duration:a,rows:i.rowCount}),i.rows}catch(t){throw console.error("Database query error:",{text:e,error:t}),t}}e.s(["queryWithEncoding",()=>n]),r()}catch(e){r(e)}},!1),23862,e=>e.a(async(t,r)=>{try{let t=await e.y("pg-587764f78a6c7a9c");e.n(t),r()}catch(e){r(e)}},!0),93695,(e,t,r)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70406,(e,t,r)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,r)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,r)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},62878,e=>{"use strict";function t(e){return"internal"===e||"external"===e}e.s(["BOOKING_STATUS",0,{pending:"001",assigned:"002",rejected:"003",completed:"004",cancelled:"005"},"isTripType",()=>t])},97469,e=>e.a(async(t,r)=>{try{var i=e.i(62294),a=e.i(62878),n=t([i]);[i]=n.then?(await n)():n;let E=null;async function s(){return E||(E=(await (0,i.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_name = 'bookings'
       AND column_name IN ('status_code', 'status')`)).some(e=>"status_code"===e.column_name)?"status_code":"status")}async function o(){let[e]=await (0,i.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.tables
       WHERE table_schema = 'public' AND table_name = 'trips'
     ) AS exists`);e?.exists||await (0,i.queryWithEncoding)(`CREATE TABLE trips (
        id SERIAL PRIMARY KEY,
        car_id INTEGER NULL REFERENCES cars(id) ON DELETE SET NULL,
        driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL,
        start_date_time TIMESTAMP NOT NULL,
        end_date_time TIMESTAMP NOT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_by VARCHAR(255),
        updated_by VARCHAR(255)
      )`);let t=(await (0,i.queryWithEncoding)(`SELECT column_name
     FROM information_schema.columns
     WHERE table_schema = 'public' AND table_name = 'bookings'`)).map(e=>e.column_name);t.includes("trip_id")||await (0,i.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN trip_id INTEGER NULL");let[r]=await (0,i.queryWithEncoding)(`SELECT EXISTS (
       SELECT 1
       FROM information_schema.table_constraints
       WHERE table_schema = 'public'
         AND table_name = 'bookings'
         AND constraint_type = 'FOREIGN KEY'
         AND constraint_name = 'bookings_trip_id_fkey'
     ) AS exists`);r?.exists||await (0,i.queryWithEncoding)("ALTER TABLE bookings ADD CONSTRAINT bookings_trip_id_fkey FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE SET NULL"),t.includes("driver_id")||await (0,i.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_id INTEGER NULL REFERENCES drivers(id) ON DELETE SET NULL"),t.includes("driver_name")||await (0,i.queryWithEncoding)("ALTER TABLE bookings ADD COLUMN driver_name VARCHAR(255)");let n=await s();for(let e of(await (0,i.queryWithEncoding)(`UPDATE bookings b
     SET driver_id = d.id
     FROM drivers d
     WHERE b.driver_id IS NULL
       AND COALESCE(TRIM(b.driver_name), '') <> ''
       AND LOWER(TRIM(d.fullname)) = LOWER(TRIM(b.driver_name))`),await (0,i.queryWithEncoding)(`SELECT id, start_time, end_time, car_id, driver_id, created_at
     FROM bookings
     WHERE trip_id IS NULL
       AND car_id IS NOT NULL
       AND ${n} = $1
     ORDER BY created_at ASC, id ASC`,[a.BOOKING_STATUS.assigned]))){let t=await (0,i.queryWithEncoding)(`INSERT INTO trips (
         car_id,
         driver_id,
         start_date_time,
         end_date_time,
         created_at,
         updated_at,
         created_by,
         updated_by
       ) VALUES ($1, $2, $3, $4, $5, CURRENT_TIMESTAMP, $6, $7)
       RETURNING id`,[e.car_id,e.driver_id,e.start_time,e.end_time,e.created_at||new Date().toISOString(),"migration","migration"]),r=t[0]?.id;r&&await (0,i.queryWithEncoding)("UPDATE bookings SET trip_id = $1 WHERE id = $2 AND trip_id IS NULL",[r,e.id])}}function d(e){if(!e)return"";let t=e instanceof Date?e:new Date(e);return Number.isNaN(t.getTime())?"":t.toISOString().slice(0,10)}e.s(["ensureTripsSchema",()=>o,"resolveBookingStatusColumn",()=>s,"toDateKey",()=>d]),r()}catch(e){r(e)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__ce6995be._.js.map