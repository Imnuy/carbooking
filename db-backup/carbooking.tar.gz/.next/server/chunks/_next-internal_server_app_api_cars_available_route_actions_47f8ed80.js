module.exports=[28548,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_cars_available_route_actions_47f8ed80.js.map